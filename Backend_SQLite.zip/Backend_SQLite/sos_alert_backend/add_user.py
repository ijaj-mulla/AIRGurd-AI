import sqlite3

def add_user(name, email, role):
    conn = sqlite3.connect("sos_alerts.db")
    cursor = conn.cursor()
    
    try:
        cursor.execute("INSERT INTO users (name, email, role) VALUES (?, ?, ?)", (name, email, role))
        conn.commit()
        print(f"User {name} added successfully.")
    except sqlite3.IntegrityError:
        print("Error: Email already exists.")
    
    conn.close()

# Example Usage
if __name__ == "__main__":
    add_user("sarthak", "sarthak.manmode@gmail.com", "Admin")
    add_user("eeil", "eeilwajar@gmail.com", "Responder")
