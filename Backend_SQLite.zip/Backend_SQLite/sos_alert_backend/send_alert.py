import sqlite3
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

# SMTP Configuration (Use your email credentials)
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587  # Use 587 with starttls OR 465 with SMTP_SSL
SENDER_EMAIL = "titumanmode@gmail.com"  # Replace with your email
SENDER_PASSWORD = "frvp ctzb jsib wsht"  # Use your App Password (not your actual password)

def get_users():
    """Fetch all users from the database."""
    conn = sqlite3.connect("sos_alerts.db")
    cursor = conn.cursor()

    cursor.execute("SELECT name, email FROM users")
    users = cursor.fetchall()

    conn.close()
    return users

def send_alert_email(subject, message):
    """Send an alert email to all users in the database."""
    users = get_users()
    
    if not users:
        print("No users found in the database.")
        return

    try:
        # Connect to SMTP Server (TLS)
        server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
        server.starttls()  # Secure connection with TLS
        server.login(SENDER_EMAIL, SENDER_PASSWORD)

        for name, email in users:
            msg = MIMEMultipart()
            msg["From"] = SENDER_EMAIL
            msg["To"] = email
            msg["Subject"] = subject

            body = f"Dear {name},\n\n{message}\n\nStay Safe!"
            msg.attach(MIMEText(body, "plain"))

            server.sendmail(SENDER_EMAIL, email, msg.as_string())
            print(f"✅ Alert sent to {email}")

        server.quit()
    except Exception as e:
        print(f"❌ Error sending email: {e}")

# Example Usage
if __name__ == "__main__":
    send_alert_email("🚨 Emergency Alert", "This is a test emergency message. Please respond immediately.")
