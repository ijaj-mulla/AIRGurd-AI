import sqlite3

def remove_user(email):
    """Remove a user from the database by email."""
    conn = sqlite3.connect("sos_alerts.db")
    cursor = conn.cursor()

    # Check if the user exists
    cursor.execute("SELECT * FROM users WHERE email = ?", (email,))
    user = cursor.fetchone()

    if user:
        cursor.execute("DELETE FROM users WHERE email = ?", (email,))
        conn.commit()
        print(f"✅ User with email {email} has been removed.")
    else:
        print(f"❌ No user found with email {email}.")

    conn.close()

# Example Usage
if __name__ == "__main__":
    email_to_remove = input("Enter the email of the user to remove: ")
    remove_user(email_to_remove)
