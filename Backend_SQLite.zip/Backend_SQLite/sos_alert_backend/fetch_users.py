import sqlite3  # Add this at the top of your script

def get_users():
    conn = sqlite3.connect("sos_alerts.db")
    cursor = conn.cursor()

    cursor.execute("SELECT name, email, role FROM users")
    users = cursor.fetchall()

    conn.close()
    return users

# Example Usage
if __name__ == "__main__":
    users = get_users()
    for user in users:
        print(user)
